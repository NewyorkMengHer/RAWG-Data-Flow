import http.client
import json

def lambda_handler(event, context):
    conn = http.client.HTTPSConnection("valorant-esports.p.rapidapi.com")
    headers = {
        'X-RapidAPI-Key': "dedc98c582msh7398b422f976afep19fcb9jsn04d355382904",
        'X-RapidAPI-Host': "valorant-esports.p.rapidapi.com"
    }
    conn.request("GET", "/standings/105590700081272455%252C105796322462986721%252C106027215534896262%252C107766270575498259", headers=headers)
    res = conn.getresponse()
    data = res.read()

    # Parse data
    data_dict = json.loads(data.decode("utf-8"))

    # TODO: Write data_dict to S3 bucket

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
